package com.fs.vo;

public class Reserve_delivery_VO {
	private String u_id;
	private String red_name;
	private String red_phone;
	private String red_kind_release;
	private int red_volume;
	private String red_delivery_date;
	private String red_address;
	private String red_detail_address;
	private int red_delivery_fee;

	public String getU_id() {
		return u_id;
	}

	public void setU_id(String u_id) {
		this.u_id = u_id;
	}

	public String getRed_name() {
		return red_name;
	}

	public void setRed_name(String red_name) {
		this.red_name = red_name;
	}

	public String getRed_phone() {
		return red_phone;
	}

	public void setRed_phone(String red_phone) {
		this.red_phone = red_phone;
	}

	public String getRed_kind_release() {
		return red_kind_release;
	}

	public void setRed_kind_release(String red_kind_release) {
		this.red_kind_release = red_kind_release;
	}

	public int getRed_volume() {
		return red_volume;
	}

	public void setRed_volume(int red_volume) {
		this.red_volume = red_volume;
	}

	public String getRed_delivery_date() {
		return red_delivery_date;
	}

	public void setRed_delivery_date(String red_delivery_date) {
		this.red_delivery_date = red_delivery_date;
	}

	public String getRed_address() {
		return red_address;
	}

	public void setRed_address(String red_address) {
		this.red_address = red_address;
	}

	public String getRed_detail_address() {
		return red_detail_address;
	}

	public void setRed_detail_address(String red_detail_address) {
		this.red_detail_address = red_detail_address;
	}

	public int getRed_delivery_fee() {
		return red_delivery_fee;
	}

	public void setRed_delivery_fee(int red_delivery_fee) {
		this.red_delivery_fee = red_delivery_fee;
	}

}

package com.fs.vo;

public class review_VO {
	
	private String searchName, searchValue; // 이름별 검색, 제목별 검색

	public String getSearchName() {
		return searchName;
	}

	public void setSearchName(String searchName) {
		this.searchName = searchName;
	}

	public String getSearchValue() {
		return searchValue;
	}

	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}
	
}
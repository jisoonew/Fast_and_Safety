package com.fs.vo;

public class Routine_delivery_VO {
	
	String u_id;
	String rd_name;
	String rd_phone;
	String rd_kind_release;
	int rd_volume;
	String rd_start;
	String rd_cycle;
	int rd_delivery_fee;
	String rd_address;
	String rd_detail_address;
	
	String kind;
	String container_type;
	String container_num;
	
	public String getU_id() {
		return u_id;
	}
	public void setU_id(String u_id) {
		this.u_id = u_id;
	}
	
	
	public String getRd_name() {
		return rd_name;
	}
	public void setRd_name(String rd_name) {
		this.rd_name = rd_name;
	}
	
	
	public String getRd_phone() {
		return rd_phone;
	}
	public void setRd_phone(String rd_phone) {
		this.rd_phone = rd_phone;
	}
	
	
	public String getRd_kind_release() {
		return rd_kind_release;
	}
	public void setRd_kind_release(String rd_kind_release) {
		this.rd_kind_release = rd_kind_release;
	}
	
	
	public int getRd_volume() {
		return rd_volume;
	}
	public void setRd_volume(int rd_volume) {
		this.rd_volume = rd_volume;
	}
	
	
	public String getRd_start() {
		return rd_start;
	}
	public void setRd_start(String rd_start) {
		this.rd_start = rd_start;
	}

	
	public int getRd_delivery_fee() {
		return rd_delivery_fee;
	}
	public void setRd_delivery_fee(int rd_delivery_fee) {
		this.rd_delivery_fee = rd_delivery_fee;
	}
	
	
	public String getRd_address() {
		return rd_address;
	}
	public void setRd_address(String rd_address) {
		this.rd_address = rd_address;
	}
	
	
	public String getRd_detail_address() {
		return rd_detail_address;
	}
	public void setRd_detail_address(String rd_detail_address) {
		this.rd_detail_address = rd_detail_address;
	}
	
	
	public String getRd_cycle() {
		return rd_cycle;
	}
	public void setRd_cycle(String rd_cycle) {
		this.rd_cycle = rd_cycle;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	
	
	public String getContainer_type() {
		return container_type;
	}
	public void setContainer_type(String container_type) {
		this.container_type = container_type;
	}
	
	
	public String getContainer_num() {
		return container_num;
	}
	public void setContainer_num(String container_num) {
		this.container_num = container_num;
	}
	
}
package com.fs.vo;

public class Storage_reserve_VO {
private String u_id;
private String sr_name;
private String sr_phone;
private String sr_category;
private int sr_volume;
private int sr_period1;
private String sr_period2;
private String sr_fee;
private String sr_start;


public String getU_id() {
	return u_id;
}
public void setU_id(String u_id) {
	this.u_id = u_id;
}
public String getSr_name() {
	return sr_name;
}
public void setSr_name(String sr_name) {
	this.sr_name = sr_name;
}
public String getSr_phone() {
	return sr_phone;
}
public void setSr_phone(String sr_phone) {
	this.sr_phone = sr_phone;
}
public String getSr_category() {
	return sr_category;
}
public void setSr_category(String sr_category) {
	this.sr_category = sr_category;
}
public int getSr_volume() {
	return sr_volume;
}
public void setSr_volume(int sr_volume) {
	this.sr_volume = sr_volume;
}
public int getSr_period1() {
	return sr_period1;
}
public void setSr_period1(int sr_period1) {
	this.sr_period1 = sr_period1;
}
public String getSr_period2() {
	return sr_period2;
}
public void setSr_period2(String sr_period2) {
	this.sr_period2 = sr_period2;
}
public String getSr_fee() {
	return sr_fee;
}
public void setSr_fee(String sr_fee) {
	this.sr_fee = sr_fee;
}
public String getSr_start() {
	return sr_start;
}
public void setSr_start(String sr_start) {
	this.sr_start = sr_start;
}
}

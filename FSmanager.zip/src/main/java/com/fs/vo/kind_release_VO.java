package com.fs.vo;

public class kind_release_VO {
	
	String u_id;
	String kind;
	String container_type;
	String container_num;
	
	public String getU_id() {
		return u_id;
	}
	public void setU_id(String u_id) {
		this.u_id = u_id;
	}
	
	
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	
	
	public String getContainer_type() {
		return container_type;
	}
	public void setContainer_type(String container_type) {
		this.container_type = container_type;
	}
	
	
	public String getContainer_num() {
		return container_num;
	}
	public void setContainer_num(String container_num) {
		this.container_num = container_num;
	}
	
}
package com.fs.dao;

import com.fs.vo.Reserve_delivery_VO;
import com.fs.vo.Routine_delivery_VO;

public interface Reserve_delivery_DAO {
	// DB 저장
		public void reserve_delivery(Reserve_delivery_VO vo);
}
